CREATE PROCEDURE pro_advice_update(IN i BIGINT)
  begin 
	declare s varchar(2);
	SELECT STATUS into s FROM system_advice WHERE id=i;
	if s='0' then
		set s='1';
	else
		set s='0';
	end if;
	UPDATE system_advice SET STATUS=s WHERE id = i;
end;
