CREATE PROCEDURE pro_zhuanMoney(OUT rs VARCHAR(20), IN cost FLOAT, IN inNo VARCHAR(40), IN outNo VARCHAR(40))
  begin
	if cost>0 then
		UPDATE `bank` SET money=money-cost WHERE bankNo=outNo;
		UPDATE bank SET money=money+cost WHERE bankNo=inNo;
		set rs = '转账成功';
	else
		set rs = '转账失败';
	end if;
end;
