CREATE PROCEDURE pro_while(IN i INT)
  begin 
	declare n int default 1;
	while n<=i do
		INSERT INTO bank VALUES(NULL,FLOOR(RAND()*1000),CONCAT('110',i),CONCAT('test',i));
		#set n=n+1;
	end while;	
end;
